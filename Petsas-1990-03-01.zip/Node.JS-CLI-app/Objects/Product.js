class Product{
  constructor(product_code,quantity,pick_location){
    this._product_code = product_code;
    this._quantity = quantity;
    this._pick_location = pick_location;
  }

  get product_code(){
    return this._product_code;
  }

  get quantity(){
    return this._quantity;
  }

  get pick_location(){
    return this._pick_location;
  }

}

module.exports = Product;
