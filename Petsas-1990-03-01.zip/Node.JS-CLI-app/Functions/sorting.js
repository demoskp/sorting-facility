function sorting(a,b) {                     // The sorting function takes 2 inputs to compare which is larger and sort accordingly
  var first = a.pick_location.split(' ');   // Since the product pick location is made of letters and numbers sperated by a space they are here placed in an array so they can be used later in the function
  var second = b.pick_location.split(' ');   // The same is done here with the second product
  if (first[0] < second[0]){      // Here we check if the letters of product a are smaller than product b and if so then place product a below product b
    return -1;
  }
  else if (first[0] > second[0]){       // Here we check if the letters of the product a are greater than product b and if so then place product a above product a
    return 1;
  }
  else if (first[0] === second[0]) {          // Here we check ifthe letters of product a and product b are the same and if so then run a second conditional statement below
    if (parseInt(first[1]) < parseInt(second[1])) {
      // Here we change the numbers of the products to integers and check if the number of product a is smaller that that of product b and is so place product a below product b
      return -1;
    } else if (parseInt(first[1]) > parseInt(second[1])){
      // Here we change the numbers of the products to integers and check if the number of product a is greater that that of product b and is so place product a above product b
      return 1;
    } else if (parseInt(first[1]) === parseInt(second[1])){
      // Here we change the numbers of the products to integers and check if the number of product a and the number of product b are equal and if so leave the order of those products the same
      return 0;
    }
  }
}

module.exports = sorting;
