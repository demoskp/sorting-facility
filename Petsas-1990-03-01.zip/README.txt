There are 2 folders in this zip file, one is for a web app that works in the browser and the second works as CLI with node.js.

The folder called Node.JS-CLI-app contains the CLI that works with node.js and reads the input file and outputs a file called output.csv containing ther sorted data.

The folder called web-app works in the browser where it asks you to browse and input a file to sort,
you then click the 'Sort File' button to sort the input file and download a new file at a location of your preference. You can also find the pickup location of a product
and it's quantity by entering the product code and clicking the 'Find pick location & Quantity' button, you will also need to have the input file uploaded in order to search for a product.


