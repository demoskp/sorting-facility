var element = document.getElementById('sorting-button');
var read_file = '';

window.onload = function() {
		var fileInput = document.getElementById('file_input');
		fileInput.addEventListener('change', function(e) {
			var file = fileInput.files[0];
			var reader = new FileReader();
			reader.onload = function(e) {
				read_file += reader.result;
			}
      reader.readAsText(file);

		});
}
