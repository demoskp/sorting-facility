function download(sorted_data) {      // Function that downloads data into a file
var element = document.createElement('a');
element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(sorted_data));
element.setAttribute('download', 'output.csv');

element.style.display = 'none';
document.body.appendChild(element);

element.click();

document.body.removeChild(element);
}
