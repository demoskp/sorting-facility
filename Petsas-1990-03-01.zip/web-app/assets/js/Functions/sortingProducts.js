function sortingProducts(){				// Function that is called when sort file button is pressed to sort the product and download the sorted file
    var stripped = read_file.replace(/(\r\n|\n|\r)/gm,",");
    var headings = stripped.split(',',3) + '\n';    // Store first 3 values seperated by commas in the variable called headings and at the end add a break line indicator for when the data will be rewritten in the output file
    var contents = stripped.split(',');              // Place the differenct contents differentiated by a comma of the variable stripped in an array called contents
    var clean_data = contents.splice(3).filter(Boolean);   // Remove the headings from the variable contents and store the new array in a variable called clean_data

    objectdata_list = organize(clean_data,3);
    var product = [];

    for (i = objectdata_list.length -1; i > -1; i--) {
    product[i] = new Product(objectdata_list[i][0],objectdata_list[i][1],objectdata_list[i][2]);  // Create an array of objects of the Class Instance Product
    }

    var product_objects = {};
    for (i = objectdata_list.length -1; i > -1; i--) {
    product_objects[objectdata_list[i][0]] = new Product(objectdata_list[i][0],objectdata_list[i][1],objectdata_list[i][2]);  // Create an array of objects of the Class Instance Product
    }

    var sorted_product = product.sort(sorting);  // Using the sorting fucntion to sort the array of objects by the pick location

    var output_data = '';
    for (i in sorted_product){

      output_data  += sorted_product[i].product_code + ',' + sorted_product[i].quantity + ',' + sorted_product[i].pick_location+'\n';
      // Using the methods of product to call the product code quantity and pick location and prepare them for exporting
    }

    var final_output_data = headings + output_data; // Putting everything in a variable including the headings for outputing in a CSV file

    download(final_output_data);			// Calling the donload function when the sortingProducts function is called to download the sorted file to the users machine

  }
