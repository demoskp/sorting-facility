function organize(myArray,split_size){      // The organize function takes in 2 inputs; an array a number which will be used as the split point of the array to create an array of arrays
  var my_products = [];

  while(myArray.length){
    my_products.push(myArray.splice(0,split_size));
  }
  return my_products;
}

//export { organize };
