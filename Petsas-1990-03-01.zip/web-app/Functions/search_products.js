function search_products(){
	var searchArgument = document.getElementById('product_code_input').value;
	var stripped = read_file.replace(/(\r\n|\n|\r)/gm,",");
	var headings = stripped.split(',',3) + '\n';    // Store first 3 values seperated by commas in the variable called headings and at the end add a break line indicator for when the data will be rewritten in the output file
	var contents = stripped.split(',');              // Place the differenct contents differentiated by a comma of the variable stripped in an array called contents
	var clean_data = contents.splice(3).filter(Boolean);   // Remove the headings from the variable contents and store the new array in a variable called clean_data

	objectdata_list = organize(clean_data,3);

	var product_objects = {};
	for (i = objectdata_list.length -1; i > -1; i--) {
	product_objects[objectdata_list[i][0]] = new Product(objectdata_list[i][0],objectdata_list[i][1],objectdata_list[i][2]);  // Create an array of objects of the Class Instance Product
	}

	var product_location = product_objects[searchArgument].pick_location;				// The pick location method is called to retrieve the product location with the searchArgument as the user product ID input
	var product_quantity = product_objects[searchArgument].quantity;
	var output_result = ('Pick location: ' + product_location + '   -----   Product Quantity: ' + product_quantity);
	var text_node = document.createTextNode(output_result);
	document.getElementById('product-code').innerHTML = output_result;
};
